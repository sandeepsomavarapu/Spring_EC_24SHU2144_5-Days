package com.nec.demo;

import org.springframework.stereotype.Component;


public class PAddress implements Address {
	int hno;
	String colony;
	String city;
	int pincode;
}
