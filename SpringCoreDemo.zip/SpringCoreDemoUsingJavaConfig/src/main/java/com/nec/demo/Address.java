package com.nec.demo;

import org.springframework.stereotype.Component;


public interface Address {

}
