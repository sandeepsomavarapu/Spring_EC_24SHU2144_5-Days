package com.nec.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("tadd")
@Primary
public class TAddress implements Address {
	int hno;
	String colony;
	String city;
	int pincode;
}
