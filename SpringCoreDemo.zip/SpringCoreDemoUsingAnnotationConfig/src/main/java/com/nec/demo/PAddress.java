package com.nec.demo;

import org.springframework.stereotype.Component;

@Component("padd")
public class PAddress implements Address {
	int hno;
	String colony;
	String city;
	int pincode;
}
