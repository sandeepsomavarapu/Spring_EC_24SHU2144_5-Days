package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.exceptions.EmployeeNotFound;
import com.example.demo.repository.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepo repo;

	@Override
	public String addEmployee(Employee employee) {
		repo.save(employee);
		return "Employee Saved ....";
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		return repo.save(employee);
	}

	@Override
	public String deleteEmployee(int empId) {
		repo.deleteById(empId);
		return "Employee Deleted !!!";
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeNotFound {
		Optional<Employee> emp = repo.findById(empId);
		if(emp.isPresent())
			return emp.get();
		else
			throw new EmployeeNotFound("There is no employee with given id...");
	}

	@Override
	public List<Employee> getAllEmployees() {

		return repo.findAll();
	}

	@Override
	public List<Employee> getAllEmployeesBetweenSalaries(float intialSal, float finalSal) {

		return repo.findByEmpSalBetween(intialSal, finalSal);
	}

	@Override
	public List<Employee> getAllByDesignation(String designation) {

		return repo.findByEmpDesg(designation);
	}

}
