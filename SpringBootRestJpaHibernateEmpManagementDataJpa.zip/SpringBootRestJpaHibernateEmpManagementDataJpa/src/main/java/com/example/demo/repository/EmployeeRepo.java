package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

//	@Query("select e from Employee e where e.empSal between ?1 and ?2")
//	public abstract List<Employee> getAllEmployeesBetweenSalaries(float intialSal, float finalSal);
//	@Query("select e from Employee e where e.empDesg=?1")
//	public abstract List<Employee> getAllByDesignation(String designation);

	public abstract List<Employee> findByEmpSalBetween(float intialSal, float finalSal);

	public abstract List<Employee> findByEmpDesg(String designation);

}
