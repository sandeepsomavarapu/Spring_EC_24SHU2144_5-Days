package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

@RestController // =@Controller+@ResponseBody
@RequestMapping("/employees")
public class EmployeeController {

//	{
//		"empId":128,
//		"empName":"pavan",
//		"empSal":92800,
//		"empDesg":"hr"
//
//		}
	@Autowired
	EmployeeService service;

	@PostMapping("/save") // http://localhost:8080/employees/save
	public String insertEmployee(@RequestBody Employee employee) {
		return service.addEmployee(employee);
	}

	@PutMapping("/merge") // http://localhost:8080/employees/merge
	public Employee mergeEmployee(@RequestBody Employee employee) {
		return service.updateEmployee(employee);
	}

	@GetMapping("/getemp/{eid}") // http://localhost:8080/employees/getemp/123 @RequestMapping(method =
									// RequestMethod.GET).
	public Employee getEmployee(@PathVariable("eid") int employeeId) {
		return service.getEmployee(employeeId);
	}

	@DeleteMapping("/deleteemp/{eid}") // http://localhost:8080/employees/deleteemp/123
	public String removeEmployee(@PathVariable("eid") int employeeId) {
		return service.deleteEmployee(employeeId);
	}

	@GetMapping("/getall") // http://localhost:8080/employees/getall
	public List<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

	@GetMapping("/getempsbetween/{sal1}/{sal2}") // http://localhost:8080/employees/getempsbetween/1000/2000
	public List<Employee> getEmployeesBetween(@PathVariable("sal1") float intialSal,
			@PathVariable("sal2") float finalSal) {
		return service.getAllEmployeesBetweenSalaries(intialSal, finalSal);
	}

	@GetMapping("/getbydesg/{designation}") // http://localhost:8080/employees/getbydesg/developer
	public List<Employee> getEmployeesByDesg(@PathVariable("designation") String empDesg) {
		return service.getAllByDesignation(empDesg);
	}
}
