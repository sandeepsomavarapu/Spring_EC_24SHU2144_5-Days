package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.exceptions.ProductNotFound;
import com.example.demo.repository.ProductRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {
		repo.save(product);
		return "product saved.....";
	}

	@Override
	public String updateProduct(Product product) {
		repo.save(product);
		return "product updated.....";
	}

	@Override
	public String deleteProduct(int productId) {
		repo.deleteById(productId);
		return "product deleted....";
	}

	@Override
	public Product getProductById(int productId) throws ProductNotFound {
		Optional<Product> optional = repo.findById(productId);
		if(optional.isPresent())
			return optional.get();
		else
			throw new ProductNotFound("ENter valid product id .....");
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.findAll();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {

		return repo.findByproductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return repo.findByProductCategory(productCategory);
	}

}
