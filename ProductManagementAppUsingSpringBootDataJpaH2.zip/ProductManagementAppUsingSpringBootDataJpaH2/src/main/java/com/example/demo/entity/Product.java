package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="products_info") //select pid from products_info; mysql   database depenedent query
public class Product {		 //select productId from Product; jpql/hql database independent query 
	@Id
	@Column(name="pid")
	@Min(value=100,message="Product id must be be above 100...")
	private int productId;
	@NotBlank(message="product name can't be empty or null")
	@Size(min = 6,max=14,message="product name must be in (6,14) length")
	private String productName;
	@Column(name="price")
	@Min(value=1000,message="product price is inavlid above 1000")
	@Max(value=100000,message="product price is inavlid below 100000")
	private int productPrice;
	@NotNull(message="product category can't be null... ")
	private String productCategory;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public Product(int productId, String productName, int productPrice, String productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}

}
