package com.kpmg.productmanagementapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.productmanagementapp.entity.Product;
import com.kpmg.productmanagementapp.exceptions.ProductNotFound;
import com.kpmg.productmanagementapp.service.ProductService;

@RestController
@RequestMapping("/products") // http://localhost:8080/products/
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/addProduct") // http://localhost:8080/products/addProduct
	public String insertProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateProduct") // http://localhost:8080/products/updateProduct
	public String mergeProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/removeProduct/{pid}") // http://localhost:8080/products/removeProduct/123
	public String deleteProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.deleteProduct(productId);
	}

	@GetMapping("/fetchProduct/{pid}") // http://localhost:8080/products/fetchProduct/123
	public Product getProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.getProduct(productId);
	}

	@GetMapping("/getAllProducts") // http://localhost:8080/products/getAllProducts
	public List<Product> fetchAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/fetchProductsBetween/{price1}/{price2}") // http://localhost:8080/products/fetchProductsBetween/1000/2000
	public List<Product> fetchAllBetween(@PathVariable("price1") int intialPrice,
			@PathVariable("price2") int finalPrice) {
		return service.getAllProductsBetweenPrice(intialPrice, finalPrice);
	}

	@GetMapping("/fetchByCategory/{category}") // http://localhost:8080/products/fetchByCategory/electronics
	public List<Product> getByCategory(@PathVariable("category") String productCategory) {
		return service.getAllProductsByCategory(productCategory);
	}
//	@ExceptionHandler(ProductNotFound.class)
//	@ResponseStatus(reason = "Product Id Is Invalid")
//	public void handlerException()
//	{
//		
//		
//	}


}
