package com.kpmg.productmanagementapp.service;

import java.util.List;

import com.kpmg.productmanagementapp.entity.Product;

public class ProductServiceImpl implements ProductService {

	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProductsBetweenPrice(int intialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {
		// TODO Auto-generated method stub
		return null;
	}

}
