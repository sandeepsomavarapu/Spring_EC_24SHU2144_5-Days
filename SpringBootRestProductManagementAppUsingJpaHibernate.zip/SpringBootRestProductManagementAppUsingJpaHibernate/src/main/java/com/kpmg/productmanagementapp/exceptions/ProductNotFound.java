package com.kpmg.productmanagementapp.exceptions;

public class ProductNotFound extends Exception {
	public ProductNotFound(String message) {
		super(message);
	}
}
