package com.kpmg.productmanagementapp.repo;

import java.util.List;

import com.kpmg.productmanagementapp.entity.Product;
import com.kpmg.productmanagementapp.exceptions.ProductNotFound;

public interface ProductRepo {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId) throws ProductNotFound;

	public abstract Product getProduct(int productId) throws ProductNotFound;

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getAllProductsBetweenPrice(int intialPrice, int finalPrice);

	public abstract List<Product> getAllProductsByCategory(String productCategory);
}
