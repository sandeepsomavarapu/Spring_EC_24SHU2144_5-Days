package com.kpmg.productmanagementapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestProductManagementAppUsingJpaHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
