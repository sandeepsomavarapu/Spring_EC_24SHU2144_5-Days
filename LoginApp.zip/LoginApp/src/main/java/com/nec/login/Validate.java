package com.nec.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class Validate extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String user = request.getParameter("uname");
		String pwd = request.getParameter("pass");
		Connection conn;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/nec", "root", "rps@123");
			PreparedStatement psmt = conn.prepareStatement("select * from gmail where username=? and password=?");
			psmt.setString(1, user);
			psmt.setString(2, pwd);
			ResultSet result = psmt.executeQuery();
			if (result.next()) {
				out.println("LOGIN SUCCESS");
				request.getRequestDispatcher("home.html").forward(request, response);
			} else
				request.getRequestDispatcher("login.html").include(request, response);

			out.println("ENTER VALID CREDENTIALS");

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
