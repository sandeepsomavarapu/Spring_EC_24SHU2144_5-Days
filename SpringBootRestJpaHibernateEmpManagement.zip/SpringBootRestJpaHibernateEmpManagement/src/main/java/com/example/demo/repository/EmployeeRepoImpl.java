package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class EmployeeRepoImpl implements EmployeeRepo {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addEmployee(Employee employee) {
		entityManager.persist(employee);
		return "Employee Saved Successfully";
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		return entityManager.merge(employee);
	}

	@Override
	public String deleteEmployee(int empId) {
		entityManager.remove(getEmployee(empId));
		return "Employee Deleted....";
	}

	@Override
	public Employee getEmployee(int empId) {

		return entityManager.find(Employee.class, empId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		TypedQuery<Employee> typedQuery = entityManager.createQuery("select e from Employee e", Employee.class);
		return typedQuery.getResultList();
	}

	@Override
	public List<Employee> getAllEmployeesBetweenSalaries(float intialSal, float finalSal) {

		TypedQuery<Employee> typedQuery = entityManager
				.createQuery("select e from Employee e where e.empSal between ?1 and ?2", Employee.class);
		typedQuery.setParameter(1, intialSal);
		typedQuery.setParameter(2, finalSal);
		return typedQuery.getResultList();
	}

	@Override
	public List<Employee> getAllByDesignation(String designation) {
		TypedQuery<Employee> typedQuery = entityManager.createQuery("select e from Employee e where e.empDesg=?1",
				Employee.class);
		typedQuery.setParameter(1, designation);
		return typedQuery.getResultList();
	}

}
