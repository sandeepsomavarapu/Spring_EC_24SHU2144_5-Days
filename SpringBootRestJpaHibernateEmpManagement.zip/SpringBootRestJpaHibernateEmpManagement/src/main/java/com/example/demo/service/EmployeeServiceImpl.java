package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepo repo;

	@Override
	public String addEmployee(Employee employee) {

		return repo.addEmployee(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		return repo.updateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int empId) {

		return repo.deleteEmployee(empId);
	}

	@Override
	public Employee getEmployee(int empId) {

		return repo.getEmployee(empId);
	}

	@Override
	public List<Employee> getAllEmployees() {

		return repo.getAllEmployees();
	}

	@Override
	public List<Employee> getAllEmployeesBetweenSalaries(float intialSal, float finalSal) {

		return repo.getAllEmployeesBetweenSalaries(intialSal, finalSal);
	}

	@Override
	public List<Employee> getAllByDesignation(String designation) {

		return repo.getAllByDesignation(designation);
	}

}
