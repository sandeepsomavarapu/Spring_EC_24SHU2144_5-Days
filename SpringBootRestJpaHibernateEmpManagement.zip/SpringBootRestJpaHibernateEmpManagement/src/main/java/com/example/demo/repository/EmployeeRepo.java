package com.example.demo.repository;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeRepo {

	public abstract String addEmployee(Employee employee);

	public abstract Employee updateEmployee(Employee employee);

	public abstract String deleteEmployee(int empId);

	public abstract Employee getEmployee(int empId);

	public abstract List<Employee> getAllEmployees();

	public abstract List<Employee> getAllEmployeesBetweenSalaries(float intialSal, float finalSal);

	public abstract List<Employee> getAllByDesignation(String designation);
}
