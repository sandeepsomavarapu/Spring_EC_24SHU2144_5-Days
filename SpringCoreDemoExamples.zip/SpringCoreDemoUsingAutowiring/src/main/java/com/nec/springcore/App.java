package com.nec.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);//lazy initializer
//		Employee emp = (Employee) factory.getBean("emp");
//		System.out.println(emp);

		
		ApplicationContext factory=new ClassPathXmlApplicationContext("springconfig.xml");//Eager Initializer
		Employee emp = (Employee) factory.getBean("emp");
		System.out.println(emp);

		
	}
}
