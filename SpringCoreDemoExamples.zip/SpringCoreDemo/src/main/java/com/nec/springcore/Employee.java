package com.nec.springcore;

public class Employee {

	private int empId;
	private String empName;
	private int empSal;
	private String empDesg;

	public Employee() {
		System.out.println("default constructor-->setter");
		}

	public Employee(int empId, String empName, int empSal, String empDesg) {
		super();
		System.out.println("from param constructor");
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDesg=" + empDesg
				+ "]";
	}

}
