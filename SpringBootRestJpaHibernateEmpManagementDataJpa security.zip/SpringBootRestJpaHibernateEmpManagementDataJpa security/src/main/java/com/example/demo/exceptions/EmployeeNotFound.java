package com.example.demo.exceptions;

public class EmployeeNotFound extends Exception {
	public EmployeeNotFound(String message) {
		super(message);
	}
}
