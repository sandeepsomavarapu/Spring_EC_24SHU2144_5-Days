package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Table(name = "emp_info")
@Entity
public class Employee {
	@Id
	@Column(name = "eid")
	@Min(value=1000,message="Empid is invalid")
	private int empId;
	@NotEmpty(message="empname cannot be empty or null")
	private String empName;
	@Min(value=10000 ,message="salary must be minimum 10000")
	@Max(value=100000 ,message="salary can be maximum 100000")
	private float empSal;
	@Size(min=6,max=12,message="designation length not satisfied (6,12)")
	private String empDesg;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empName, float empSal, String empDesg) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

}
