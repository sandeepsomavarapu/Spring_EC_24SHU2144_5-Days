package com.kpmg.productmanagementapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kpmg.productmanagementapp.entity.Product;
import com.kpmg.productmanagementapp.repo.ProductRepo;

import jakarta.transaction.Transactional;

@Service // @Service,@Repository
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repository;

	@Override
	public String addProduct(Product product) {

		return repository.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		return repository.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return repository.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return repository.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return repository.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetweenPrice(int intialPrice, int finalPrice) {

		return repository.getAllProductsBetweenPrice(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return repository.getAllProductsByCategory(productCategory);
	}

}
