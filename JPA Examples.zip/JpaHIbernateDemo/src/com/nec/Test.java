package com.nec;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		EntityManager em = emf.createEntityManager();
		// persist,merge,remove,find-->1 row operations
		// Employee emp = new Employee(124, "suresh", 12345, "trainer");
		em.getTransaction().begin();
//		em.persist(emp);
		
		//JPQL,HQL

		Employee emp = em.find(Employee.class, 124);
		System.out.println(emp);

//		emp.setEmpDesg("developer");
//		emp.setEmpName("mahesh");
//		em.merge(emp);

		em.remove(emp);
		em.getTransaction().commit();

	}

}
